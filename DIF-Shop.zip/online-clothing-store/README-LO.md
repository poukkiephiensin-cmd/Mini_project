# DIF Shop — ຄູ່ມືຕິດຕັ້ງແລະທົດສອບ

ລະບົບນີ້ໃຊ້ **HTML, CSS, JavaScript, PHP ແລະ MySQL**. ລາຍການສິນຄ້າ, ລາຄາ, ສະຕັອກ, ໃບສັ່ງຊື້ ແລະ ການຊຳລະ ອ່ານຈາກຖານຂໍ້ມູນ `online_clothing_store` ຕົວຈິງ. ບໍ່ມີການເພີ່ມຕາຕະລາງ ຫຼື ຖັນໃໝ່.

## 1. ກຽມ XAMPP ແລະ MySQL

1. ຕິດຕັ້ງ XAMPP ທີ່ມີ PHP 8 ຂຶ້ນໄປ, ເປີດ Apache ແລະ ເປີດ PHP extensions `pdo_mysql`, `mbstring` ແລະ `gd` (ສຳລັບອັບໂຫຼດຮູບ).
2. ໃຊ້ **MySQL Community Server 8.0.16 ຂຶ້ນໄປ**. XAMPP ຫຼາຍລຸ້ນໃຊ້ MariaDB ເຖິງວ່າປຸ່ມຈະຂຽນວ່າ “MySQL”. ຖ້າເປັນ MariaDB, ໃຫ້ໃຊ້ Apache/PHP/phpMyAdmin ຂອງ XAMPP ແຕ່ເຊື່ອມຫາ MySQL Community Server ທີ່ຕິດຕັ້ງແຍກ. ຢ່າໃຫ້ສອງບໍລິການໃຊ້ port ດຽວກັນ.
3. ແຕກ ZIP ໃຫ້ໄດ້ `C:\xampp\htdocs\online-clothing-store\index.php`.

## 2. ນຳເຂົ້າຖານຂໍ້ມູນໃນ phpMyAdmin

ເປີດ `http://localhost/phpmyadmin/` ແລະ ກວດວ່າເຊື່ອມຫາ MySQL ຖືກເຄື່ອງ/port ດ້ວຍ `SELECT VERSION();`. ໃນ **Import**, ເລືອກ UTF-8 ແລ້ວນຳເຂົ້າຕາມລຳດັບ:

1. `database/online_clothing_store.sql` — ໄຟລ໌ schema ຕົ້ນສະບັບ. **ຂ້າມ** ຖ້າມີ 6 ຕາຕະລາງເດີມຢູ່ແລ້ວ.
2. `database/sample-data.sql` — ຂໍ້ມູນຈາກ Excel ທັງ 6 ຊີດ. ນຳເຂົ້າເທື່ອດຽວໃນຕາຕະລາງເປົ່າ. **ບໍ່ຕ້ອງນຳເຂົ້າຊ້ຳ** ຖ້າມີຂໍ້ມູນນັ້ນຢູ່ແລ້ວ.

## 3. ຕັ້ງຄ່າການເຊື່ອມຕໍ່ ແລະ ລະຫັດ Admin

ເປີດ **Command Prompt** ແລ້ວລັນ:

```bat
cd C:\xampp\htdocs\online-clothing-store
C:\xampp\php\php.exe tools\configure.php
```

ໃສ່ host, port, ຊື່ຜູ້ໃຊ້ ແລະ ລະຫັດຜ່ານ MySQL ຂອງທ່ານ. ຈາກນັ້ນຕັ້ງຊື່ແລະລະຫັດ Admin ຂອງຮ້ານ. ໂປຣແກຣມຈະສ້າງ `C:\xampp\dif-private\config.php` **ນອກ htdocs** ແລະ ເກັບລະຫັດ Admin ໃນຮູບແບບ hash. ບໍ່ມີບັນຊີ Admin ສຳເລັດຮູບໃນ ZIP. ຢ່ານຳໄຟລ໌ private config ໄປໄວ້ໃນໂຟນເດີເວັບ.

- **ໜ້າຮ້ານ:** `http://localhost/online-clothing-store/`
- **ໜ້າ Admin:** `http://localhost/online-clothing-store/admin/`

ຖ້າໃຊ້ path ອື່ນ ໃຫ້ກຳນົດ `DIF_CONFIG` ເປັນທີ່ຢູ່ໄຟລ໌ private config. ລາຍລະອຽດຢູ່ໃນ `README.md`.

## 4. ກວດຜົນກ່ອນສາທິດ

```bat
set DIF_CONFIG=C:\xampp\dif-private\config.php
C:\xampp\php\php.exe tests\verify.php --sample
```

ການກວດນີ້ອ່ານຂໍ້ມູນຢ່າງດຽວ. ຫຼັງຕິດຕັ້ງໃໝ່ຈະມີສິນຄ້າ 5 SKU, ໃບສັ່ງຊື້ 3 ໃບ ແລະ ການຊຳລະ 4 ລາຍການ. ຍອດໃບ `1001` ແມ່ນ **370,000 ₭**; ຍອດຂາຍລວມຈາກລາຍການ `paid` ແມ່ນ **635,000 ₭**.

**ລອງສັ່ງຊື້:** ເລືອກສີ/ຂະໜາດ → Add to Bag → Checkout. ຖ້າຊື້ເສື້ອ `TEE-WHT-M` 2 ຕົວ ແລະ ໂສ້ງ `JEAN-BLU-30` 1 ໂຕ ພ້ອມຄ່າສົ່ງປົກກະຕິ 15,000 ₭, ຍອດໃບໃໝ່ແມ່ນ **380,000 ₭**. ລາຄາໃບເກົ່າບໍ່ປ່ຽນຕາມ ເພາະໃຊ້ `order_details.unit_price` ຂອງແຕ່ລະໃບ.

**ການຊຳລະ:** ລາຍການໃໝ່ເລີ່ມທີ່ `pending`. Admin ກວດຍອດທີ່ໄດ້ຮັບກ່ອນໝາຍ `paid`. ການລອງຈ່າຍໃໝ່ສ້າງອີກລາຍການ ບໍ່ລຶບປະຫວັດການຈ່າຍຄັ້ງກ່ອນ. ໂຄງງານນີ້ບໍ່ໄດ້ຫັກເງິນຈາກທະນາຄານຈິງ. Newsletter ບັນທຶກລາຍຊື່ຜູ້ສະໝັກໃນໄຟລ໌ private ແຕ່ບໍ່ສົ່ງອີເມວອັດຕະໂນມັດ.
