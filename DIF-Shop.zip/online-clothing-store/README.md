# DIF Shop — Online Clothing Store

A working PHP/MySQL clothing boutique for the Database Tech Stack course. The public shop and private studio use the **same six original tables**. No framework, JavaScript build step, remote font, CDN, payment gateway or additional application table is required.

**ຄູ່ມືພາສາລາວ:** [README-LO.md](README-LO.md). See also [database notes](docs/DATABASE.md) and [tested behaviours](docs/TESTING.md).

## 1. Install with XAMPP and MySQL

1. Install **XAMPP with PHP 8+** and enable Apache. PHP needs `pdo_mysql`, `mbstring`, `fileinfo` and **GD** for image uploads. If an extension is disabled, enable its `extension=...` entry in `C:\xampp\php\php.ini`, then restart Apache. Use a 64-bit PHP installation.
2. Use **MySQL Community Server 8.0.16 or later**. Many XAMPP distributions label their bundled *MariaDB* service “MySQL”; that is a different server. To meet the course requirement, use XAMPP's **Apache/PHP/phpMyAdmin** with the actual MySQL service. If two database services are installed, stop the unused one or give them distinct ports. Confirm with `SELECT VERSION();` in phpMyAdmin.
3. Extract the folder as `C:\xampp\htdocs\online-clothing-store\`. `index.php` must be directly inside it, not in a second nested folder. On other operating systems, use the equivalent Apache document root.
4. Start MySQL and Apache. Open `http://localhost/phpmyadmin/`. If needed, select the real MySQL server in phpMyAdmin. In XAMPP's `phpMyAdmin/config.inc.php`, use the correct server `host` (`127.0.0.1`), `port` (e.g. `3306` or `3307`) and `auth_type = 'cookie'` for that server entry. Log in with a local account that can create this database and its tables.
5. **Import once, in order** using phpMyAdmin → **Import**, file character set `utf-8`:
   - `database/online_clothing_store.sql`: the supplied schema, copied byte-for-byte. Creates `online_clothing_store` and its six tables. If the original schema is already installed, **skip this file**.
   - `database/sample-data.sql`: exact rows from `database/reference/online_clothing_examples.xlsx`. Import only into **empty tables**, not over an existing shop. If the sample rows already exist, **skip this file**. The seed is transactional and includes the stock snapshot; **do not subtract the sample orders from stock again**.
6. Create the private connection/admin settings. Run from **Command Prompt**:

   ```bat
   cd C:\xampp\htdocs\online-clothing-store
   C:\xampp\php\php.exe tools\configure.php
   ```

   Enter the MySQL host, port, user and password. For a default local XAMPP setup the user may be `root` with a blank password; use the actual credentials of **your MySQL service**. Choose a studio username and a new 12–72-byte password. Run the wizard privately: typed input is visible in the terminal. It writes `C:\xampp\dif-private\config.php`, **outside `htdocs`**, and stores only a password hash for the studio login. It never overwrites existing settings.
7. Open the storefront at **`http://localhost/online-clothing-store/`**. The studio is **`http://localhost/online-clothing-store/admin/`** or **Studio admin** in the footer. Use the account chosen in step 6. There is **no default admin password** in the distribution.

For a nonstandard document root or Apache alias, pass a private absolute filename to `tools/configure.php` and set the **`DIF_CONFIG`** environment variable to that file for PHP. In an Apache virtual host: `SetEnv DIF_CONFIG "C:/private/dif/config.php"`, then restart Apache. Do not use the public web directory for private files.

### Check the installation (read-only)

```bat
cd C:\xampp\htdocs\online-clothing-store
set DIF_CONFIG=C:\xampp\dif-private\config.php
C:\xampp\php\php.exe tests\verify.php --sample
```

Run `--sample` just after importing the untouched workbook. After regular store activity, omit `--sample` to check only the schema and payment invariants. A fresh store has **3 customers, 3 categories, 5 product variations, 3 orders, 5 order lines and 4 payment attempts**. Sample order `1001` totals **370,000 ₭**. Sample verified sales are **635,000 ₭**.

### Optional PHP development server

With a running MySQL service and a private `DIF_CONFIG` already configured:

```sh
php -S 127.0.0.1:8000 -t . config/dev-router.php
```

Use the router: it serves only the public pages and assets, not configuration, tests or database files. The built-in server is for local coursework, not production hosting.

## 2. Use the storefront

- Browse **Home** / **Shop**. Category links, keyword/SKU search, sorting, stock and prices use live queries. New Arrivals uses descending `product_id` because the original table does not contain a creation date. Featured Products selects a representative SKU per category. Best Sellers ranks units from non-cancelled orders with a verified payment, without multiplying line items by payment attempts.
- Product pages link to the actual variations of the same category and product name. Each variation has its own ID, SKU, price, size, colour and inventory.
- Add a quantity to the PHP-session bag. Use **Update quantity** to save a change or **Remove** to remove the line.
- Checkout accepts an optional email and a separate shipping recipient. Phone numbers remain strings. Standard delivery is **15,000 ₭**, priority **25,000 ₭**. These are server-side delivery policies, not changes to the schema. The chosen fee is saved in `orders.shipping_fee`.
- After successful checkout, the receipt shows the snapshot unit prices, delivery, total, fulfilment status, payment method and attempt status. Receipts are available only in the session that placed the order (or via the protected admin order desk).

## 3. Use the studio

| Page | Operations |
|---|---|
| Overview | Customer, SKU, order and pending-order counts; sales from **paid** records; recent orders; inventory |
| Products | Search, add, edit, adjust stock, assign a category, upload/reset a local photo, delete an unreferenced SKU |
| Categories | Add, edit, delete only when no products reference the category |
| Customers | Search name/email/phone; view the customer record and complete order history |
| Orders | Filter by status, review lines, recipient and shipping; view dynamic totals; progress or cancel eligible orders |
| Payments | Filter attempts; verify pending payments as paid or failed; add new/partial attempts from an order detail |

**Suggested demonstration:** order two `TEE-WHT-M` and one `JEAN-BLU-30` with standard shipping. The new total is `(2 × 85,000) + 195,000 + 15,000 = 380,000 ₭`. The sample historical order `1001` remains `370,000 ₭` because its tee was sold at `80,000 ₭`.

### Fulfilment and payment policy

- New orders and all new payment attempts start **pending**. No money is collected by the site itself. Bank transfers and QR payments are manually verified; cash is verified after collection. This is a university project, **not a live banking integration**.
- Optionally set `transfer_instructions` in the **private config array**, and place your own merchant QR image at `assets/images/payment-qr.png`. Transfer instructions and the optional QR are shown only on an eligible unpaid receipt. No test bank account is invented.
- On the admin order page, **Record a new attempt** preserves past failed attempts. Verify funds before selecting **Verified paid**. Successful payments set `paid_at`; failed and pending records keep it `NULL`. Resolved attempts are not overwritten. The verified amount cannot exceed the remaining order balance.
- Status flow: `pending → confirmed → shipped → completed`. Completion requires full verified payment. Unpaid pending/confirmed orders may be cancelled; their stock is restored **once**, and unresolved attempts become failed. Cancelled/completed orders are final. Refunds are outside this six-table model.
- A historical SKU cannot be deleted. To stop new purchases without losing its history, set its stock to zero.

## 4. Private configuration, images and storage

`config/database.php` opens PDO with **native prepares, exceptions and utf8mb4**. `config/settings.php` loads private settings. `config/admin_config.php` uses the private username/hash or the optional environment overrides `DIF_ADMIN_USER` and `DIF_ADMIN_HASH` (a `password_hash()` output, not a plain password). Missing admin credentials disable login. To reset the password locally, back up the private configuration outside the web root, rerun the CLI wizard, and preserve your database settings.

For a dedicated database account, create it as the database administrator and grant only `SELECT, INSERT, UPDATE, DELETE` on `online_clothing_store.*`. The web app does not need schema-management privileges. Do not expose phpMyAdmin or a root account to the Internet.

- **Images:** no `image` column. `image_for()` first checks `uploads/product-<ID>.jpg`, then the original SKU-to-file map, then a neutral local placeholder. Uploaded JPG/PNG/WebP files are size-checked, decoded, resized and re-encoded as JPEG. `uploads/` must be writable by Apache. Catalogue and editorial photography here is AI-generated illustration for the project.
- **Newsletter:** the form de-duplicates and stores addresses in `newsletter.json` in private `storage_dir`, with a file lock. It creates no seventh table and sends no email. The private directory must be writable by PHP. Login rate-limit files are private as well.
- **Fonts:** local Libre Caslon Display, DM Sans and Noto Sans Lao; their SIL Open Font Licenses are included under `assets/fonts/`.
- **Security:** all write forms use CSRF tokens and POST; text is escaped at output; SQL values are bound parameters; sort clauses are allowlisted. Admin sessions rotate at login/logout, expire after 30 minutes of inactivity, and failed login attempts are limited. Use HTTPS and restrict private-file permissions. Keep Apache's supplied `.htaccess` protection enabled (`AllowOverride All` for this local project). Live-preview partitioned cookies are an opt-in preview setting; local installs default to same-site cookies.

## 5. Project map

```text
online-clothing-store/
  index.php, products.php, product-detail.php, about.php
  cart.php, checkout.php, order-success.php, newsletter.php
  admin/          Login, dashboard, product/category/customer/order/payment management
  includes/       Store and studio layouts, validation, session helpers, auth, checkout transactions
  config/         PDO, private settings loader, admin config, optional development router
  assets/         Local CSS, vanilla JS, photography, fonts and licenses
  uploads/        Managed product JPEGs; no executable uploads
  database/       Unmodified DDL, matching workbook seed, original workbook and latest 1:N diagram
  tools/          Local-only private configuration wizard
  tests/          Read-only PHP database verifier
  docs/           Database design decisions and test record
```

### Troubleshooting

- **Store temporarily unavailable:** start the real MySQL server; verify host, port, `DIF_CONFIG`, database grants and both imports. Review Apache's PHP error log; the public site deliberately does not show raw connection errors.
- **Empty catalogue:** the schema import creates empty tables. Import `database/sample-data.sql` once if you want the original fixtures.
- **Studio cannot sign in:** run the wizard, use the private username/password, and allow cookies. A ten-minute throttle applies after eight failed attempts. Open the preview in its own tab if your browser blocks embedded cookies.
- **Photos do not upload:** enable GD, allow writes in `uploads/` and `storage_dir`, set `upload_max_filesize` to at least 4M and `post_max_size` above that, then restart Apache. Accepted photos are capped at 4 MB and 12 megapixels.
- **Characters are not readable:** import the provided files as UTF-8. Do not convert the tables or workbook to a legacy code page.
