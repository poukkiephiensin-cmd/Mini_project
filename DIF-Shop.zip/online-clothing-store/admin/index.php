<?php

require_once __DIR__.'/../includes/auth.php';
require_admin();
go('admin/dashboard.php');
