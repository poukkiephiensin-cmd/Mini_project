<?php require_once __DIR__.'/../includes/studio.php';
$s = strval_input($_GET, 'status');
if (!in_array($s, ORDER_STATES, true)) {
    $s = '';
}
$list = rows(ORDER_TOTALS.($s ? ' WHERE o.order_status=?' : '').' ORDER BY o.order_id DESC', $s ? [$s] : []);
studio_head('Order desk', 'orders', 'Open an order to review its items, delivery, payments and status.');?><form class="admin-filter admin-toolbar"><select aria-label="Filter order status" name="status"><option value="">All statuses</option><?php foreach (ORDER_STATES as $o):?><option value="<?=$o?>" <?=$o === $s ? 'selected' : ''?>><?=ucfirst($o)?></option><?php endforeach;?></select><button class="btn outline">Filter</button></form><?php orders_table($list);
studio_foot();?>
