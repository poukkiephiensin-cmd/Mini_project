<?php require_once __DIR__.'/includes/functions.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_post();
    try {
        $id = positive($_POST['product_id'] ?? '');
        $act = choice('action', ['add','update','remove']);
        $cart = bag();
        if ($act === 'remove') {
            unset($cart[$id]);
            $msg = 'Piece removed from your bag.';
        } else {
            $p = row('SELECT stock_qty,sku FROM products WHERE product_id=?', [$id]);
            if (!$p) {
                throw new InputError('This piece is no longer available.');
            }
            $n = positive($_POST['quantity'] ?? '', 99);
            if ($act === 'add') {
                $n += $cart[$id] ?? 0;
            }
            if ($n > 99 || $n > $p['stock_qty']) {
                throw new InputError('Only '.min(99, $p['stock_qty']).' of '.$p['sku'].' can be added to your bag.');
            }
            $cart[$id] = $n;
            if (count($cart) > 40) {
                throw new InputError('A bag can contain up to 40 different variations.');
            }
            $msg = $act === 'add' ? 'Piece added to your bag.' : 'Quantity updated.';
        }
        $_SESSION['cart'] = $cart;
        unset($_SESSION['checkout_nonce'],$_SESSION['quote']);
        flash($msg);
    } catch (InputError $e) {
        flash($e->getMessage(), 'error');
    }
    go('cart.php');
}
$items = cart_rows();
if (count($items) !== count(bag())) {
    $_SESSION['cart'] = array_intersect_key(bag(), array_flip(array_column($items, 'product_id')));
    unset($_SESSION['checkout_nonce'],$_SESSION['quote']);
    flash('An unavailable piece was removed from your bag.');
}
$title = 'Your bag';
require __DIR__.'/includes/header.php';?>
<main class="wrap page" id="main"><div class="crumb"><a href="<?=u('products.php')?>">Shop</a> / Bag</div><p class="eyebrow"><b></b> YOUR SELECTION</p><h1>Shopping Bag<em>.</em></h1><?php if (!$items):?><div class="empty"><p class="eyebrow">THE WARDROBE AWAITS</p><h2>Your bag is empty.</h2><p>Find a piece to make your own.</p><a href="<?=u('products.php')?>" class="btn dark">Shop the collection <?=icon('arrow')?></a></div><?php else:?><div class="two-col"><div><?php foreach ($items as $p):?><div class="bag-item"><a href="<?=u('product-detail.php?id='.$p['product_id'])?>"><img src="<?=h(image_for($p))?>" alt="<?=h($p['product_name'])?>"></a><div><div class="sku"><?=h($p['sku'])?></div><h3><a href="<?=u('product-detail.php?id='.$p['product_id'])?>"><?=h($p['product_name'])?></a></h3><p><?=h($p['color'].' / '.$p['size_label'])?></p><p><?=h(money($p['price']))?> each</p><form method="post"><?=csrf()?><input type="hidden" name="action" value="remove"><input type="hidden" name="product_id" value="<?=$p['product_id']?>"><button class="mini-link">Remove</button></form></div><div class="right"><strong><?=h(money($p['line_total']))?></strong><form method="post"><?=csrf()?><input type="hidden" name="action" value="update"><input type="hidden" name="product_id" value="<?=$p['product_id']?>"><div class="stepper"><button type="button" data-step="-1" aria-label="Decrease quantity">−</button><input type="number" name="quantity" aria-label="Quantity for <?=h($p['sku'])?>" min="1" max="<?=max(1, min(99, $p['stock_qty']))?>" value="<?=$p['qty']?>" required><button type="button" data-step="1" aria-label="Increase quantity">+</button></div><br><button class="mini-link">Update quantity</button></form></div></div><?php endforeach;?><div class="bag-foot"><a href="<?=u('products.php')?>" class="text-link">← Continue shopping</a><span class="small muted"><?=bag_count()?> item(s)</span></div></div><aside class="summary-card"><p class="eyebrow">THE DETAILS</p><h2>Bag summary</h2><p class="small muted">Estimate with standard delivery. Choose your delivery service at checkout.</p><?php summary(cart_total($items), cents(SHIPPING['standard']));?><a class="btn dark full" href="<?=u('checkout.php')?>">Proceed to Checkout <?=icon('arrow')?></a></aside></div><?php endif;?></main><?php require __DIR__.'/includes/footer.php';?>
