<?php require_once __DIR__.'/includes/orders.php';
$isPost = $_SERVER['REQUEST_METHOD'] === 'POST';
if ($isPost) {
    check_post();
    $key = strval_input($_POST, 'checkout_nonce');
    if (isset($_SESSION['completed_checkouts'][$key])) {
        go('order-success.php?id='.(int)$_SESSION['completed_checkouts'][$key]);
    }
}
if (!bag()) {
    flash('Add a piece to your bag before checking out.');
    go('cart.php');
}
$items = cart_rows();
if (count($items) !== count(bag())) {
    flash('Your bag has changed. Please review it before checking out.');
    go('cart.php');
}
$err = '';
$same = !$isPost || isset($_POST['same_shipping']);
$service = strval_input($_POST, 'service', 'standard');
if (!isset(SHIPPING[$service])) {
    $service = 'standard';
}
$method = strval_input($_POST, 'payment_method', 'cash_on_delivery');
if ($isPost) {
    try {
        if (empty($_SESSION['checkout_nonce']) || !hash_equals($_SESSION['checkout_nonce'], $key)) {
            throw new InputError('Your bag changed or the checkout expired. Review the current summary before placing the order.');
        }
        $d = ['full_name' => field('full_name', 120),'phone' => phone_field('phone'),'email' => email_field('email'),'address' => field('address', 255),'service' => choice('service', array_keys(SHIPPING)),'payment_method' => choice('payment_method', array_keys(METHODS))];
        $d['recipient_name'] = $same ? $d['full_name'] : field('recipient_name', 120);
        $d['recipient_phone'] = $same ? $d['phone'] : phone_field('recipient_phone');
        $d['shipping_address'] = $same ? $d['address'] : field('shipping_address', 255);
        $oid = place_order(bag(), $d, $_SESSION['quote'] ?? []);
        $_SESSION['completed_checkouts'][$key] = $oid;
        $_SESSION['completed_checkouts'] = array_slice($_SESSION['completed_checkouts'], -25, null, true);
        $_SESSION['cart'] = [];
        unset($_SESSION['quote'],$_SESSION['checkout_nonce']);
        go('order-success.php?id='.$oid);
    } catch (InputError $e) {
        $err = $e->getMessage();
    } catch (PDOException $e) {
        error_log('[DIF checkout] '.$e->getCode());
        $err = 'The order was not placed. Please check the contact details and try again. Your bag has been kept.';
    }
}
$items = cart_rows();
$_SESSION['quote'] = array_column($items, 'price', 'product_id');
$_SESSION['checkout_nonce'] = bin2hex(random_bytes(24));
$title = 'Checkout';
require __DIR__.'/includes/header.php';?>
<main class="wrap page" id="main"><div class="crumb"><a href="<?=u('cart.php')?>">Shopping bag</a> / Checkout</div><p class="eyebrow"><b></b> THE FINAL DETAILS</p><h1>Checkout<em>.</em></h1><?php if ($err):?><div role="alert" class="error-box"><?=h($err)?> <a class="mini-link" href="<?=u('cart.php')?>">Review bag</a></div><?php endif;?>
<form method="post" class="two-col" data-once><?=csrf()?><input type="hidden" name="checkout_nonce" value="<?=h($_SESSION['checkout_nonce'])?>"><div><section class="form-section"><h2><span>01 /</span>Customer information</h2><div class="field-grid"><?php input_box('Full name', 'full_name', strval_input($_POST, 'full_name'), 'text', true, 120);
input_box('Phone number', 'phone', strval_input($_POST, 'phone'), 'tel', true, 25);?><div class="span2"><?php input_box('Email address (optional)', 'email', strval_input($_POST, 'email'), 'email', false, 254);?></div><label class="field span2"><span>Address</span><textarea name="address" required maxlength="255" rows="2" placeholder="House, street, village and district"><?=h(strval_input($_POST, 'address'))?></textarea></label></div></section><section class="form-section"><h2><span>02 /</span>Shipping information</h2><label class="checkline"><input type="checkbox" name="same_shipping" value="1" <?=$same ? 'checked' : ''?>>Use my contact details for delivery</label><div class="field-grid" data-shipping-fields><?php input_box('Recipient name', 'recipient_name', strval_input($_POST, 'recipient_name'), 'text', false, 120);
input_box('Recipient phone', 'recipient_phone', strval_input($_POST, 'recipient_phone'), 'tel', false, 25);?><label class="field span2"><span>Shipping address</span><textarea name="shipping_address" maxlength="255" rows="2"><?=h(strval_input($_POST, 'shipping_address'))?></textarea></label></div><div class="choice-list"><?php foreach (SHIPPING as $k => $v):?><label><input name="service" type="radio" value="<?=$k?>" data-cents="<?=cents($v)?>" <?=$service === $k ? 'checked' : ''?>><?=ucfirst($k)?> delivery <small><?=money($v)?></small></label><?php endforeach;?></div></section><section class="form-section"><h2><span>03 /</span>Payment method</h2><div class="choice-list"><?php foreach (METHODS as $k => $v):?><label><input type="radio" name="payment_method" value="<?=$k?>" <?=$method === $k ? 'checked' : ''?> required><?=$v?></label><?php endforeach;?></div><p class="small muted">Payment is recorded as pending. Bank and QR transfers are verified by the studio; cash is collected on delivery. No funds are taken on this page.</p></section></div><aside class="summary-card"><p class="eyebrow">YOUR SELECTION</p><h2>Order summary</h2><?php foreach ($items as $p):?><div class="order-line"><img src="<?=h(image_for($p))?>" alt=""><div class="grow"><?=h($p['product_name'])?><p><?=h($p['sku'])?> · Qty <?=$p['qty']?></p><p><?=money($p['price'])?> each</p></div><span><?=money($p['line_total'])?></span></div><?php endforeach;
summary(cart_total($items), cents(SHIPPING[$service]));?><button class="btn dark full" type="submit">Place order <?=icon('arrow')?></button><a class="mini-link" href="<?=u('cart.php')?>">Edit your bag</a></aside></form></main><?php require __DIR__.'/includes/footer.php';?>
