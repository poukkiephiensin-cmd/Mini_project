<?php

require_once __DIR__.'/includes/functions.php';
check_post();
try {
    $email = mb_strtolower(email_field('email', true));
    $f = fopen(private_dir().'/newsletter.json', 'c+');
    if (!$f || !flock($f, LOCK_EX)) {
        throw new RuntimeException('Cannot open subscription list');
    }
    try {
        $raw = stream_get_contents($f);
        $all = $raw ? json_decode($raw, true, 512, JSON_THROW_ON_ERROR) : [];
        $all[$email] ??= date(DATE_ATOM);
        rewind($f);
        ftruncate($f, 0);
        if (fwrite($f, json_encode($all, JSON_THROW_ON_ERROR)) === false) {
            throw new RuntimeException('Subscription write failed');
        }
        fflush($f);
    } finally {
        flock($f, LOCK_UN);
        fclose($f);
    }
    flash('Thank you. Your address is on the DIF letter list.');
} catch (InputError $e) {
    flash($e->getMessage(), 'error');
}
go('index.php#newsletter');
