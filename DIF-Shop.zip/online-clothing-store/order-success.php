<?php require_once __DIR__.'/includes/orders.php';
$id = rid();
if (!in_array($id, $_SESSION['completed_checkouts'] ?? [], true)) {
    fail_page(404, 'This order is not available in this session.');
}
$o = row(ORDER_TOTALS.' WHERE o.order_id=?', [$id]);
if (!$o) {
    fail_page(404, 'Order not found.');
}
$lines = order_lines($id);
$pays = rows('SELECT payment_method,payment_status,amount FROM payments WHERE order_id=? ORDER BY payment_id', [$id]);
$title = 'Order confirmation';
require __DIR__.'/includes/header.php';?>
<main class="wrap page" id="main"><div class="crumb">DIF Shop / Order confirmation</div><p class="eyebrow"><b></b> ORDER #<?=$id?></p><h1>Thank you<em>.</em></h1><p class="intro">Your order has been received. Keep order number <strong>#<?=$id?></strong> for your records.</p><div class="two-col"><div><section class="receipt-section"><h2>Order details</h2><div class="receipt-meta"><?=status_tag($o['order_status'])?><span><?=h($o['ordered_at'])?> · Vientiane time</span></div><?php foreach ($lines as $p):?><div class="order-line"><img src="<?=h(image_for($p))?>" alt=""><div class="grow"><?=h($p['product_name'])?><p><?=h($p['sku'])?> · <?=$p['quantity']?> × <?=money($p['unit_price'])?></p></div><?=money($p['line_total'])?></div><?php endforeach;?></section><section class="receipt-section"><h2>Delivery</h2><p>Ordered by <?=h($o['full_name'])?></p><p><?=h($o['recipient_name'].' · '.$o['recipient_phone'])?><br><?=nl2br(h($o['shipping_address']))?></p></section><a class="text-link" href="<?=u('products.php')?>">Continue shopping <?=icon('arrow')?></a></div><aside class="summary-card"><p class="eyebrow">RECEIPT / <?=$id?></p><h2>Order summary</h2><?php summary(cents($o['subtotal']), cents($o['shipping_fee']));?><p class="small">Verified paid: <strong><?=money($o['paid_total'])?></strong></p><hr><?php foreach ($pays as $p):?><p class="receipt-meta"><?=h(METHODS[$p['payment_method']])?> <?=status_tag($p['payment_status'])?> <?=money($p['amount'])?></p><?php endforeach;
$pendingMethods = array_column(array_filter($pays, fn ($x) => $x['payment_status'] === 'pending'), 'payment_method');
if (cents($o['grand_total']) > cents($o['paid_total']) && array_intersect($pendingMethods, ['bank_transfer','qr'])):?><hr><p class="eyebrow">PAYMENT INSTRUCTIONS</p><p class="small"><?=nl2br(h(settings()['transfer_instructions'] ?? 'No bank destination is configured in this local demonstration. No money was collected. The studio must verify a transfer before marking it paid.'))?></p><?php if (in_array('qr', $pendingMethods, true) && is_file(STORE_ROOT.'/assets/images/payment-qr.png')):?><img class="merchant-qr" src="<?=u('assets/images/payment-qr.png')?>" alt="Studio payment QR code"><?php endif;endif;?></aside></div></main><?php require __DIR__.'/includes/footer.php';?>
