<?php require_once __DIR__.'/includes/functions.php';
$catRaw = strval_input($_GET, 'category');
$cat = $catRaw !== '' ? (int)$catRaw : 0;
$q = mb_substr(strval_input($_GET, 'q'), 0, 100);
$sort = strval_input($_GET, 'sort', 'editor');
$sorts = ['editor' => 'p.category_id,p.product_id','new' => 'p.product_id DESC','price_asc' => 'p.price ASC,p.product_id','price_desc' => 'p.price DESC,p.product_id'];
if (!isset($sorts[$sort])) {
    $sort = 'editor';
}
$where = [];
$args = [];
$category = null;
if ($catRaw !== '') {
    $category = row('SELECT * FROM categories WHERE category_id=?', [$cat]);
    if (!$category) {
        fail_page(404, 'This category is not in the wardrobe.');
    }
    $where[] = 'p.category_id=?';
    $args[] = $cat;
}
if ($q !== '') {
    $where[] = '(p.product_name LIKE ? OR p.sku LIKE ? OR p.color LIKE ? OR c.category_name LIKE ?)';
    $match = $q;
    foreach (cats() as $cc) {
        if (strcasecmp(cat_title($cc['category_name']), $q) === 0) {
            $match = $cc['category_name'];
        }
    }
    array_push($args, '%'.$q.'%', '%'.$q.'%', '%'.$q.'%', '%'.$match.'%');
}
$list = rows(PRODS.($where ? ' WHERE '.implode(' AND ', $where) : '').' ORDER BY '.$sorts[$sort], $args);
$active = $category ? 'cat-'.$cat : 'shop';
$title = $category ? cat_title($category['category_name']) : 'The Collection';
require __DIR__.'/includes/header.php';?>
<main id="main" class="wrap page"><div class="crumb"><a href="<?=u('index.php')?>">Home</a> / Shop</div><p class="eyebrow"><b></b> THE DIF WARDROBE</p><h1><?=h($title)?><em>.</em></h1><p class="intro"><?=h($category ? $category['description'] : 'Considered silhouettes, quiet textures, and pieces for every day.')?></p>
<form method="get" class="filter-form"><label class="search-field"><?=icon('search')?><input type="search" name="q" placeholder="Search the wardrobe" aria-label="Search the wardrobe" value="<?=h($q)?>" maxlength="100"></label><label>Category<select name="category"><option value="">All categories</option><?php foreach (cats() as $c):?><option value="<?=$c['category_id']?>" <?=$cat == (int)$c['category_id'] ? 'selected' : ''?>><?=h(cat_title($c['category_name']))?></option><?php endforeach;?></select></label><label>Sort by<select name="sort"><?php foreach (['editor' => 'Studio selection','new' => 'Newest first','price_asc' => 'Price: low to high','price_desc' => 'Price: high to low'] as $k => $v):?><option value="<?=$k?>" <?=$sort === $k ? 'selected' : ''?>><?=$v?></option><?php endforeach;?></select></label><button class="btn dark">Apply</button></form>
<div class="listing-meta"><span><?=count($list)?> <?=count($list) === 1 ? 'piece' : 'pieces'?><?=$q !== '' ? ' for “'.h($q).'”' : ''?></span><?php if ($q || $cat || $sort !== 'editor'):?><a class="mini-link" href="<?=u('products.php')?>">Clear filters ×</a><?php endif;?></div>
<div class="product-grid catalog-grid"><?php foreach ($list as $p) {
    product_card($p);
}?></div><?php if (!$list):?><div class="empty"><p class="eyebrow">SEARCH NOTES</p><h2>No pieces found.</h2><p>Try a different search or explore the full collection.</p><a class="btn dark" href="<?=u('products.php')?>">View the collection</a></div><?php endif;?></main><?php require __DIR__.'/includes/footer.php';?>
